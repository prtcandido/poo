package com.example;

import java.math.BigDecimal;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity // Indica que esta classe é uma entidade JPA e será mapeada para uma tabela no banco de dados
public class Produto {
    @Id // Indica que o campo 'id' é a chave primária da entidade
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Especifica que o valor do campo 'id' será gerado automaticamente pelo banco de dados, 
                                                        // utilizando a estratégia de incremento automático
    private Long id;
    private String nome;
    private BigDecimal preco;

    public Produto() {}

    public Produto(String nome, BigDecimal preco) {
        this.nome = nome;
        this.preco = preco;
    }

    @Override
    public String toString() {
        return "Produto{id=" + id + ", nome='" + nome + "', preco=" + preco + "}";
    }
}
