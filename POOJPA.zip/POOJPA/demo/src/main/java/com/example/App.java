package com.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import org.hibernate.cfg.Configuration;

import java.math.BigDecimal;
import java.util.List;

public class App {
    public static void main(String[] args) {
        // 2. Configuração Programática do Hibernate
        Configuration config = new Configuration(); // Cria uma instância de Configuration
        config.setProperty("hibernate.connection.driver_class", "org.sqlite.JDBC"); // Define o driver JDBC para SQLite
        config.setProperty("hibernate.connection.url", "jdbc:sqlite:meubanco.db"); // Define a URL de conexão para o banco de dados SQLite
        config.setProperty("hibernate.dialect", "org.hibernate.community.dialect.SQLiteDialect"); // Define o dialeto do Hibernate para SQLite
        config.setProperty("hibernate.hbm2ddl.auto", "update"); // mantém a estrutura do banco de dados atualizada com base nas entidades mapeadas
        config.setProperty("hibernate.show_sql", "true"); // Exibe as instruções SQL geradas pelo Hibernate no console

        // Registra a classe
        config.addAnnotatedClass(Produto.class);

        // 3. Execução
        // Os objetos EntityManagerFactory e EntityManager são criados dentro de um bloco try-with-resources para garantir que sejam fechados automaticamente após o uso.
        // Não sendo necessário fechar manualmente o EntityManager e o EntityManagerFactory.
        try (EntityManagerFactory emf = config.buildSessionFactory(); // cria uma fábrica de EntityManager a partir da configuração do Hibernate
             EntityManager em = emf.createEntityManager()) { // cria um EntityManager para gerenciar as operações de persistência

            // Inserir Registro
            em.getTransaction().begin(); // inicia uma transação para garantir que as operações de persistência sejam executadas de forma atômica
            Produto p1 = new Produto("Teclado Mecânico", new BigDecimal("250.00")); // cria uma nova instância da entidade Produto
            em.persist(p1); // persiste o objeto Produto no banco de dados, tornando-o gerenciado pelo EntityManager
            em.getTransaction().commit(); // confirma a transação, salvando as alterações no banco de dados

            System.out.println("\n--- PRODUTO SALVO COM SUCESSO ---\n");

            // Consultar Registros
            List<Produto> lista = em.createQuery("SELECT p FROM Produto p", Produto.class)
                                    .getResultList();
            
            System.out.println("--- LISTA NO BANCO DE DADOS ---");
            lista.forEach(System.out::println);
        }
    }
}
